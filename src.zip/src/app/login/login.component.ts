import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private us:UserService, private router:Router) { }

  ngOnInit(): void {
  }

  loginUser(user:any)
  {
    this.us.getUserById(user.username).subscribe(data =>{
      if(data[0].password==user.password)
      {
        sessionStorage.setItem('user', user.username);
        this.router.navigate(['list']);
      }
      else alert("Invali Username/Password")
    })
  }

}
