import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private us:UserService, private router:Router) { }

  ngOnInit(): void {
  }

  registerUser(user:any)
  {
    this.us.addUser(user).subscribe(data => {
      alert("User Registered Successfully");
      this.router.navigate(['login']);
    })
  }

}
