import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  isViewProduct:Boolean = false;
  isAddProduct:Boolean = false;
  constructor(public us: AuthService, private as:AuthService, private router:Router) {
   }

  ngOnInit(): void {
  }

  logoutUser()
  {
    this.as.logoutSession();
    this.router.navigate(['login'])
  }
  
}
