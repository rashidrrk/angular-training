export interface Product{
 id:number,
 productName:string,
 productPrice:number
}