import { Product } from "./product";
export let products:Product[] = [
    {id:1, productName:"Pencil", productPrice:15.0},
    {id:2, productName:"Eraser", productPrice:5.0},
    {id:3, productName:"NoteBook", productPrice:30.0},
    {id:4, productName:"Sharpener", productPrice:12.0}
]