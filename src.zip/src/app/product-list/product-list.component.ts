import { Component, OnInit, SimpleChanges, Input } from '@angular/core';
import { Product } from '../modal/product';
import { products } from '../modal/data';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  productList:Product[];
  constructor(private ps:ProductService) { 
    this.productList=[];
  }

  ngOnInit(): void {
    this.ps.getAllProduct().subscribe( data => this.productList=data);
  }

}
