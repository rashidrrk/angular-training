import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url:string="http://localhost:3000";
  constructor(private http:HttpClient) { }

  getAllProduct()
  {
    return this.http.get<any>(`${this.url}/products`);
  }

  getProductById(id:number)
  {
    return this.http.get<any>(`${this.url}/products?id=${id}`)
  }

  addProduct(product:any)
  {
    return this.http.post<any>(`${this.url}/products`, product);
  }
}
