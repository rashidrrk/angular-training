import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../modal/product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  @Input()
  prod:Product={
    id: 0,
    productName: '',
    productPrice: 0
  };
  constructor() { }

  ngOnInit(): void {
  }

}
