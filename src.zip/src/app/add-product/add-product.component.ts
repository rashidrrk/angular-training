import { outputAst } from '@angular/compiler';
import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from '../modal/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  prodForm:FormGroup;
  id:FormControl;
  productName:FormControl;
  productPrice:FormControl;
  constructor(private ps:ProductService, private router:Router) { 
    this.id= new FormControl('',[ Validators.required])
    this.productName = new FormControl('',[Validators.required]);
    this.productPrice = new FormControl('',[Validators.required, Validators.pattern(/^\d+\.\d{0,2}$/)]);   
    
    this.prodForm = new FormGroup(
      {
        id:this.id,
        productName: this.productName,
        productPrice: this.productPrice
      });
  }
  ngOnInit(): void {
  }

  addProduct(prodForm:FormGroup)
  {
    this.ps.addProduct(prodForm.value).subscribe(data =>{
      if(data)
      {
        alert("Product added succesfully");
        this.router.navigate(['list'])
      }
      else alert("Unable to add product, please try later");
    });
  }

}
